package com.example.pizzasearchview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    lateinit var pizzaRV: RecyclerView
    lateinit var pizzaAdapter: PizzaAdapter
    lateinit var pizzaList: ArrayList<Pizza>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        pizzaRV = findViewById(R.id.recyclerviewPizza)

        pizzaList = ArrayList()

        pizzaAdapter = PizzaAdapter(pizzaList)

        pizzaRV.adapter = pizzaAdapter

        pizzaList.add(Pizza("Pizza Hut", R.drawable.pizza_hut))
        pizzaList.add(Pizza("Papa John's", R.drawable.papa_johns))
        pizzaList.add(Pizza("Mario's Pizza", R.drawable.marios_pizza))
        pizzaList.add(Pizza("Taco Bell", R.drawable.taco_bell))

        pizzaAdapter.notifyDataSetChanged()

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater

        inflater.inflate(R.menu.search_menu, menu)

        val searchItem: MenuItem = menu.findItem(R.id.actionSearch)

        val searchView: SearchView = searchItem.getActionView() as SearchView

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener,
            android.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(p0: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(msg: String): Boolean {
                filter(msg)
                return false
            }
        })
        return true
    }

    private fun filter(text: String) {
        val filteredlist: ArrayList<Pizza> = ArrayList()

        for (item in pizzaList) {
            if (item.name.toLowerCase().contains(text.toLowerCase())) {
                filteredlist.add(item)
            }
        }
        if (filteredlist.isEmpty()) {
            Toast.makeText(this, "No Data Found..", Toast.LENGTH_SHORT).show()
        } else {
            pizzaAdapter.filterList(filteredlist)
        }
    }
}