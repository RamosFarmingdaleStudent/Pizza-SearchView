package com.example.pizzasearchview

data class Pizza(var name: String, var img: Int)
