package com.example.pizzasearchview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PizzaAdapter(
    private var courseList: ArrayList<Pizza>,
) : RecyclerView.Adapter<PizzaAdapter.CourseViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): PizzaAdapter.CourseViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(
            R.layout.pizza_rv_item,
            parent, false
        )

        return CourseViewHolder(itemView)
    }

    fun filterList(filterlist: ArrayList<Pizza>) {
        courseList = filterlist
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: PizzaAdapter.CourseViewHolder, position: Int) {
        holder.courseNameTV.text = courseList.get(position).name
        holder.courseIV.setImageResource(courseList.get(position).img)
    }

    override fun getItemCount(): Int {
        return courseList.size
    }

    class CourseViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val courseNameTV: TextView = itemView.findViewById(R.id.pizzaName)
        val courseIV: ImageView = itemView.findViewById(R.id.idPizzaPlace)
    }
}
